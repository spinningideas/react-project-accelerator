import DefaultLayout from "layouts/DefaultLayout";

export default function Application() {
  return <DefaultLayout></DefaultLayout>;
}
