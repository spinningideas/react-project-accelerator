export default interface ContactSubmission {
  name?: string;
  email?: string;
  message: string;
}
